import numpy as np

# abstract class -- super class
class BaseLayer:
    def __init__(self):
        self.trainable = False
    